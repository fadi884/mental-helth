import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = "http://127.0.0.1:8000";      

  Future<bool> login(String email, String password) async {
    final response = await http.post(
      Uri.parse("$baseUrl/login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email, "password": password}),
    );

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      print("Token: ${data['token']}"); // يمكنك تخزين التوكن هنا
      return true;
    } else {
      print("خطأ في تسجيل الدخول: ${response.body}");
      return false;
    }
  }
}
